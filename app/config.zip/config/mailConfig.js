const basicConfig = {
    SENDGRID_API_KEY: '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',
}
module.exports = basicConfig
